\
import React, { useRef, useState, useEffect } from "react";

// MusicWaveApp.jsx
export default function MusicWaveApp() {
  const audioRef = useRef(null);
  const fileInputRef = useRef(null);
  const canvasWaveRef = useRef(null);
  const canvasFreqRef = useRef(null);
  const [audioContext, setAudioContext] = useState(null);
  const analyserRef = useRef(null);
  const sourceRef = useRef(null);
  const rafRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [useMic, setUseMic] = useState(false);
  const [fileName, setFileName] = useState("");
  const [volume, setVolume] = useState(0.8);
  const gainRef = useRef(null);

  useEffect(() => {
    return () => {
      stopVisualization();
      if (audioContext) {
        try { audioContext.close(); } catch (e) {}
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const ensureAudioContext = async () => {
    if (audioContext && audioContext.state !== "closed") return audioContext;
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    setAudioContext(ctx);
    analyserRef.current = ctx.createAnalyser();
    analyserRef.current.fftSize = 2048;
    gainRef.current = ctx.createGain();
    gainRef.current.gain.value = volume;
    analyserRef.current.connect(ctx.destination);
    gainRef.current.connect(analyserRef.current);
    return ctx;
  };

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setUseMic(false);
    stopMicStream();
    const url = URL.createObjectURL(file);

    if (!audioRef.current) audioRef.current = new Audio();
    audioRef.current.src = url;
    audioRef.current.crossOrigin = "anonymous";
    audioRef.current.loop = false;

    const ctx = await ensureAudioContext();

    if (sourceRef.current) {
      try { sourceRef.current.disconnect(); } catch (e) {}
    }

    sourceRef.current = ctx.createMediaElementSource(audioRef.current);
    sourceRef.current.connect(gainRef.current);
    audioRef.current.volume = 1;

    audioRef.current.onplay = () => {
      setIsPlaying(true);
      if (ctx.state === "suspended") ctx.resume();
      startVisualization();
    };
    audioRef.current.onpause = () => setIsPlaying(false);
    audioRef.current.onended = () => setIsPlaying(false);

    try {
      await audioRef.current.play();
    } catch (err) {}
  };

  const startMic = async () => {
    setFileName("Microphone");
    const ctx = await ensureAudioContext();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stopSource();
      sourceRef.current = ctx.createMediaStreamSource(stream);
      sourceRef.current._stream = stream;
      sourceRef.current.connect(gainRef.current);
      setUseMic(true);
      startVisualization();
      setIsPlaying(true);
    } catch (err) {
      alert("Could not access microphone: " + err.message);
    }
  };

  const stopMicStream = () => {
    if (sourceRef.current && sourceRef.current._stream) {
      const tracks = sourceRef.current._stream.getTracks();
      tracks.forEach((t) => t.stop());
      try { sourceRef.current.disconnect(); } catch (e) {}
      sourceRef.current = null;
    }
  };

  const stopSource = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    stopMicStream();
    if (sourceRef.current) {
      try { sourceRef.current.disconnect(); } catch (e) {}
      sourceRef.current = null;
    }
    setIsPlaying(false);
  };

  const stopVisualization = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
  };

  const startVisualization = () => {
    stopVisualization();
    const canvas = canvasWaveRef.current;
    const canvasFreq = canvasFreqRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !canvasFreq || !analyser) return;

    const ctx = canvas.getContext("2d");
    const fctx = canvasFreq.getContext("2d");
    const bufferLength = analyser.fftSize;
    const dataArray = new Uint8Array(bufferLength);
    const freqLength = analyser.frequencyBinCount;
    const freqArray = new Uint8Array(freqLength);

    const draw = () => {
      rafRef.current = requestAnimationFrame(draw);
      analyser.getByteTimeDomainData(dataArray);
      analyser.getByteFrequencyData(freqArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      fctx.clearRect(0, 0, canvasFreq.width, canvasFreq.height);

      ctx.lineWidth = 2;
      ctx.beginPath();
      const sliceWidth = (canvas.width * 1.0) / bufferLength;
      let x = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * canvas.height) / 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.stroke();

      const barWidth = (canvasFreq.width / freqLength) * 2.5;
      let bx = 0;
      for (let i = 0; i < freqLength; i++) {
        const v = freqArray[i];
        const h = (v / 255) * canvasFreq.height;
        fctx.fillStyle = `rgba(${Math.min(255, v + 50)}, ${150}, ${255 - v})`;
        fctx.fillRect(bx, canvasFreq.height - h, barWidth, h);
        bx += barWidth + 1;
      }
    };
    draw();
  };

  const togglePlay = async () => {
    if (!audioRef.current && !useMic) return;
    if (useMic) {
      if (isPlaying) {
        stopMicStream();
        setIsPlaying(false);
      } else {
        await startMic();
      }
      return;
    }

    if (audioRef.current.paused) {
      try {
        if (audioContext && audioContext.state === "suspended") await audioContext.resume();
        await audioRef.current.play();
        setIsPlaying(true);
        startVisualization();
      } catch (err) {
        console.error(err);
      }
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
      stopVisualization();
    }
  };

  const handleVolume = (val) => {
    setVolume(val);
    if (gainRef.current) gainRef.current.gain.value = val;
  };

  const handleClear = () => {
    stopSource();
    stopVisualization();
    setFileName("");
    if (fileInputRef.current) fileInputRef.current.value = null;
  };

  // Resize canvases to device pixel ratio for crispness
  useEffect(() => {
    const resize = () => {
      const c1 = canvasWaveRef.current;
      const c2 = canvasFreqRef.current;
      if (!c1 || !c2) return;
      const ratio = window.devicePixelRatio || 1;
      const rect1 = c1.getBoundingClientRect();
      const rect2 = c2.getBoundingClientRect();
      c1.width = Math.floor(rect1.width * ratio);
      c1.height = Math.floor(rect1.height * ratio);
      c2.width = Math.floor(rect2.width * ratio);
      c2.height = Math.floor(rect2.height * ratio);
      const ctx1 = c1.getContext('2d');
      const ctx2 = c2.getContext('2d');
      ctx1.scale(ratio, ratio);
      ctx2.scale(ratio, ratio);
    };
    window.addEventListener('resize', resize);
    resize();
    return () => window.removeEventListener('resize', resize);
  }, []);

  // === Recording (auto-download) ===
  const mediaRecorderRef = useRef(null);
  const recordedChunksRef = useRef([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const options = { mimeType: 'audio/webm' };
      const mr = new MediaRecorder(stream, options);
      recordedChunksRef.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };
      mr.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' });
        // convert to WAV-like filename (browser will keep webm; still OK)
        const now = new Date();
        const stamp = now.toISOString().replace(/[:]/g, '-').replace(/\..+/, '');
        const filename = `recording_${stamp}.webm`;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      };
      mediaRecorderRef.current = mr;
      mr.start();
      setIsPlaying(true);
    } catch (err) {
      alert('Recording failed: ' + err.message);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      // stop tracks
      try {
        mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
      } catch (e) {}
      mediaRecorderRef.current = null;
    }
    setIsPlaying(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-indigo-100 to-white dark:from-slate-900 dark:via-indigo-900 dark:to-black text-black dark:text-white p-6 flex items-start justify-center">
      <div className="w-full max-w-4xl bg-white/60 dark:bg-black/40 backdrop-blur-md rounded-2xl p-6 shadow-2xl">
        <header className="mb-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Music Wave — React Visualizer</h1>
          <div className="flex items-center gap-3">
            <ThemeToggle />
          </div>
        </header>

        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div className="md:col-span-2">
            <div className="rounded-lg overflow-hidden border border-black/5 dark:border-white/10">
              <canvas ref={canvasWaveRef} style={{ width: '100%', height: 160 }} />
              <canvas ref={canvasFreqRef} style={{ width: '100%', height: 120 }} />
            </div>
            <div className="mt-3 flex items-center gap-3">
              <button
                className="px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-600 text-white transition"
                onClick={togglePlay}
              >
                {useMic ? (isPlaying ? 'Stop Mic' : 'Start Mic') : (isPlaying ? 'Pause' : 'Play')}
              </button>

              <label className="px-4 py-2 rounded-lg bg-slate-700 cursor-pointer text-white">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  onChange={handleFile}
                  className="hidden"
                />
                Upload Audio
              </label>

              <button className="px-3 py-2 rounded-lg bg-rose-600 text-white" onClick={handleClear}>Clear</button>

              <div className="ml-auto text-sm opacity-80">{fileName || 'No source'}</div>
            </div>
          </div>

          <aside className="p-4 rounded-lg border border-black/5 bg-white/50 dark:bg-black/30">
            <div className="space-y-4">
              <div>
                <div className="text-xs uppercase opacity-80">Volume</div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={volume}
                  onChange={(e) => handleVolume(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>

              <div>
                <div className="text-xs uppercase opacity-80">Microphone</div>
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={startMic}
                    className="flex-1 px-3 py-2 rounded-md bg-green-500 hover:bg-green-600 text-white"
                  >
                    Use Mic
                  </button>
                  <button
                    onClick={stopMicStream}
                    className="flex-1 px-3 py-2 rounded-md bg-amber-500 hover:bg-amber-600 text-white"
                  >
                    Stop Mic
                  </button>
                </div>
              </div>

              <div>
                <div className="text-xs uppercase opacity-80">Recording</div>
                <div className="flex gap-2 mt-2">
                  <button onClick={startRecording} className="flex-1 px-3 py-2 rounded-md bg-indigo-600 text-white">Start Record</button>
                  <button onClick={stopRecording} className="flex-1 px-3 py-2 rounded-md bg-red-600 text-white">Stop & Download</button>
                </div>
                <div className="text-sm mt-2 opacity-80">Recorded file will auto-download with current date/time.</div>
              </div>

              <div>
                <div className="text-xs uppercase opacity-80">Tips</div>
                <ul className="text-sm mt-2 list-disc pl-4 opacity-85 text-slate-800 dark:text-slate-200">
                  <li>Upload MP3 / WAV / OGG files.</li>
                  <li>Allow microphone access to visualize live audio.</li>
                  <li>Use headphones for lower feedback when using mic + speakers.</li>
                </ul>
              </div>

              <div className="pt-2 text-xs opacity-70">Built with Web Audio API · Canvas · React · Tailwind</div>
            </div>
          </aside>
        </div>

        <footer className="mt-6 text-center text-sm opacity-80">Want extra features? (export waveform image, zoom) — tell me and I'll add them.</footer>
      </div>
    </div>
  );
}

// Simple Theme Toggle component (uses localStorage + document class)
function ThemeToggle(){
  const [dark, setDark] = useState(() => {
    try {
      return localStorage.getItem('music-wave-dark') === '1';
    } catch { return false; }
  });
  useEffect(() => {
    try {
      localStorage.setItem('music-wave-dark', dark ? '1' : '0');
    } catch {}
    if (dark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [dark]);
  return (
    <button onClick={() => setDark(!dark)} className="px-3 py-2 rounded bg-slate-200 dark:bg-slate-800">
      {dark ? 'Light' : 'Dark'}
    </button>
  );
}

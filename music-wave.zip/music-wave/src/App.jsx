import React from 'react';
import MusicWaveApp from './MusicWaveApp';

export default function App(){
  return <MusicWaveApp />;
}

# music-wave

A React audio visualizer with waveform + frequency bars, microphone input, recording (auto-download), and light/dark theme toggle. Built with Create React App + Tailwind CSS.

## Quick start

1. Unzip the project.
2. Install dependencies:

```bash
npm install
```

3. Start the dev server:

```bash
npm start
```

Open http://localhost:3000 in your browser.

